//
//  AppDelegate.h
//  OAuthTest
//
//  Created by Matthew McGlincy on 3/17/12.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
