//
//  SiteReachabilityAppDelegate.h
//  SiteReachability
//
//  Created by Lukhnos D. Liu on 6/30/09.
//  Copyright Lithoglyph Inc. 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SiteReachabilityViewController;

@interface SiteReachabilityAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    SiteReachabilityViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet SiteReachabilityViewController *viewController;

@end

