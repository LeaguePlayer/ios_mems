Session Login sample

Demonstrates how to use the FBSession object to login to Facebook and manage access tokens.

Build Requirements
iOS 4.0 SDK

Runtime Requirements
iPhone OS 4.0 or later

Using the Sample
Install the Facebook SDK for iOS.
Launch the SessionLoginSample project using Xcode from the
<Facebook SDK>/samples/SessionLoginSample directory.

Changes from Previous Versions
1.0 - First release.


