Profile Picture Control sample

Demonstrates how to use the Profile picture control provided with 
the Facebook SDK for iOS.

Build Requirements
iOS 4.0 SDK

Runtime Requirements
iPhone OS 4.0 or later

Using the Sample
Install the Facebook SDK for iOS.
Launch the ProfilePictureSample project using Xcode from the <Facebook SDK>/samples/ProfilePictureSample directory.

Changes from Previous Versions
1.0 - First release.

