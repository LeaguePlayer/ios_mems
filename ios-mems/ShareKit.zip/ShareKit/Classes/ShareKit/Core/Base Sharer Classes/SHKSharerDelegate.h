//
//  SHKSharerDelegate.h
//  ShareKit
//
//  Created by Vilem Kurz on 2.1.2012.
//  Copyright (c) 2012 Cocoa Miners. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SHKSharer.h"

@interface SHKSharerDelegate : NSObject <SHKSharerDelegate>

@end
