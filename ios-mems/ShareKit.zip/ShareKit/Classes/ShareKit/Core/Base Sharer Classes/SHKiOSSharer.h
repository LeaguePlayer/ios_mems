//
//  SHKiOSSharerViewController.h
//  ShareKit
//
//  Created by Vilem Kurz on 18/11/2012.
//
//

#import "SHKSharer.h"

@interface SHKiOSSharer : SHKSharer

@end
