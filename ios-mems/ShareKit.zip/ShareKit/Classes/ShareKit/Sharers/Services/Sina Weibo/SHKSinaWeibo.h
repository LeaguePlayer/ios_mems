//
//  SHKSinaWeibo.h
//  ShareKit
//
//  Created by Vilém Kurz on 11/18/12.
//
//

#import "SHKiOSSharer.h"

@interface SHKSinaWeibo : SHKiOSSharer

@end
