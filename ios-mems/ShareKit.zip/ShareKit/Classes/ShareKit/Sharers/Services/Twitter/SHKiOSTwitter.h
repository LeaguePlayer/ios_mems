//
//  SHKiOS5Twitter.h
//  ShareKit
//
//  Created by Vilem Kurz on 17.11.2011.
//  Copyright (c) 2011 Cocoa Miners. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SHKiOSSharer.h"

@interface SHKiOSTwitter : SHKiOSSharer

@end
