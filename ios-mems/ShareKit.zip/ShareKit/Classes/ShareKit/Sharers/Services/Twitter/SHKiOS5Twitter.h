//
//  SHKiOS5Twitter.h
//  ShareKit
//
//  Created by Vilem Kurz on 18/11/2012.
//
//

#import "SHKSharer.h"

/* after we stop supporting iOS5 this sharer might be deleted */

@interface SHKiOS5Twitter : SHKSharer

@end
