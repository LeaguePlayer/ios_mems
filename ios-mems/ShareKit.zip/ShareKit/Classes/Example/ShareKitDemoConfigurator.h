//
//  ShareKitDemoConfigurator.h
//  ShareKit
//
//  Created by Vilem Kurz on 12.11.2011.
//  Copyright (c) 2011 Cocoa Miners. All rights reserved.
//

#import "DefaultSHKConfigurator.h"

@interface ShareKitDemoConfigurator : DefaultSHKConfigurator

@end
