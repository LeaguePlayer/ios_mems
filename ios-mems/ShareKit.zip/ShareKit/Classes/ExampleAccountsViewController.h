//
//  ExampleAccountsViewController.h
//  ShareKit
//
//  Created by Chris White on 1/22/13.
//
//

#import <UIKit/UIKit.h>

@interface ExampleAccountsViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@end
