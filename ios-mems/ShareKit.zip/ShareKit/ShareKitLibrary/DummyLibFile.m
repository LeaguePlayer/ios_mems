//
//  DummyLibFile.m
//  ShareKit
//
//  Created by Vilém Kurz on 11/20/12.
//
//

#import "DummyLibFile.h"

@implementation DummyLibFile

@end
